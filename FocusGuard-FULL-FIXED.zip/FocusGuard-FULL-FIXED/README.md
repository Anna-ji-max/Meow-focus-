# FocusGuard

A small Android accessibility-service app that places focus overlays over selected Instagram surfaces.

## Build

The included GitHub Actions workflow builds a debug APK automatically.

## Important

FocusGuard uses Android's AccessibilityService API. Android requires the user to explicitly enable an accessibility service in system settings. Only enable an accessibility service you understand and trust.
